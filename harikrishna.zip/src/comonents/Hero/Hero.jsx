import React from "react";
import "../Hero/Hero.css";
import leafImage from "../../utils/leaf.png";

const Hero = () => {
  return (
    <div class="hero-main h-90">
      <div className="d-flex justify-content-center flex-column align-items-center leaf">
        <img src={leafImage} alt="leafimg" />
        <h2>manaChoice 100% Natural, Organic, and Best Delivery Services</h2>
      </div>
    </div>
  );
};

export default Hero;
